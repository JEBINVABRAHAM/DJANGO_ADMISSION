from django.contrib import admin
from faculty.models import faculty

# Register your models here.
admin.site.register(faculty)

